let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;
let pontuacao = 0;

let machado;
let machadoImg;
let tempoParaProximoMachado = 0;
let intervaloMachadoMin = 5000;
let intervaloMachadoMax = 15000;

let particulas = [];

// Variáveis para sons (se você quiser adicionar)
let somPlantio;
let somCorte;
let somReplantio;
let somPonto;
let somPerdaPonto;

// NOVAS VARIÁVEIS PARA EVENTOS ALEATÓRIOS
let proximoEventoTempo = 0;
let intervaloEventoMin = 10000; // 10 segundos
let intervaloEventoMax = 30000; // 30 segundos
let eventoAtual = null; // 'chuva', 'praga', null
let duracaoEvento = 0;
let tempoInicioEvento = 0;

function preload() {
    machadoImg = loadImage("machado.png");

    // Descomente e adicione os caminhos dos seus arquivos de som se tiver:
    // somPlantio = loadSound('assets/plant.mp3');
    // somCorte = loadSound('assets/chop.mp3');
    // somReplantio = loadSound('assets/replant.mp3');
    // somPonto = loadSound('assets/point.mp3');
    // somPerdaPonto = loadSound('assets/lose_point.mp3');
}

function setup() {
    createCanvas(600, 400);
    resetarJogo();
}

function draw() {
    let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208), map(totalArvores, 0, 50, 0, 1));
    background(corFundo);
    mostrarInformacao();

    // Lógica da temperatura e eventos
    temperatura += 0.01; // Temperatura sobe lentamente
    gerenciarEventosAleatorios(); // NOVA CHAMADA

    jardineiro.mostrar();
    jardineiro.atualizar();

    // --- Lógica do Machado ---
    tempoParaProximoMachado -= deltaTime;
    if (tempoParaProximoMachado <= 0 && !machado.ativo) {
        machado.aparecerAleatoriamente();
    }

    if (machado.ativo) {
        machado.exibir();
        machado.atualizar();

        for (let i = plantas.length - 1; i >= 0; i--) {
            let arvore = plantas[i];
            if (!arvore.cortada && arvore.estagio === 2 && machado.atingiu(arvore)) {
                arvore.cortada = true;
                totalArvores--;
                if (totalArvores < 0) totalArvores = 0;
                pontuacao = max(0, pontuacao - 35); // Penalidade maior por perder uma árvore adulta
                // if (somPerdaPonto) somPerdaPonto.play(); // Adicione som se tiver

                for (let p = 0; p < 15; p++) {
                    particulas.push(new Particula(arvore.x + arvore.largura / 2, arvore.y + arvore.altura / 2));
                }

                machado.desaparecer();
                reiniciarTempoMachado();
                break;
            }
        }
    }

    // --- Lógica das Plantas (Árvores) ---
    for (let i = plantas.length - 1; i >= 0; i--) {
        let planta = plantas[i];
        planta.mostrar();
        planta.atualizar();
    }

    // --- Lógica das Partículas ---
    for (let i = particulas.length - 1; i >= 0; i--) {
        let p = particulas[i];
        p.atualizar();
        p.mostrar();
        if (p.alpha <= 0) {
            particulas.splice(i, 1);
        }
    }

    // --- Ajusta a dificuldade do Machado ---
    let fatorDificuldade = map(totalArvores, 0, 50, 0, 1);
    machado.velocidade = 2 + (fatorDificuldade * 3);
    intervaloMachadoMin = lerp(5000, 2000, fatorDificuldade);
    intervaloMachadoMax = lerp(15000, 7000, fatorDificuldade);

    // BÔNUS: Pontos pela temperatura baixa
    if (temperatura < 15) {
        pontuacao += 0.1; // Bônus contínuo, um pouco maior
    }
    // Garante que a temperatura não vá muito além de um ponto razoável sem um limite de "perda"
    if (temperatura > 40) { // Exemplo de limite superior para manter o desafio
        temperatura = 40;
    }
}

function mostrarInformacao() {
    textSize(20);
    fill(0);
    text("Temperatura: " + temperatura.toFixed(2) + "°C", 10, 30);
    text("Árvore plantadas: " + totalArvores, 10, 50);
    text("Pontuação: " + floor(pontuacao), 10, 70);
    text("Para movimentar use as setas.", 10, 90);
    text("ESPAÇO: Plantar muda. R: Replantar toco. P: Reiniciar.", 10, 110); // ATUALIZADO
    textAlign(LEFT, BASELINE); // Volta para o alinhamento padrão

    // Exibir mensagem de evento
    if (eventoAtual === 'chuva') {
        fill(0, 0, 200); // Azul
        textSize(24);
        textAlign(CENTER, CENTER); // Centraliza texto do evento
        text("Chuva Abençoada! ☔ (+25 pontos)", width / 2, 30);
        textAlign(LEFT, BASELINE); // Volta para o alinhamento padrão
    } else if (eventoAtual === 'praga') {
        fill(200, 0, 0); // Vermelho
        textSize(24);
        textAlign(CENTER, CENTER); // Centraliza texto do evento
        text("Praga de Insetos! 🐛 (-20 pontos)", width / 2, 30);
        textAlign(LEFT, BASELINE); // Volta para o alinhamento padrão
    }
}

// --- NOVA FUNÇÃO: Gerenciar Eventos Aleatórios ---
function gerenciarEventosAleatorios() {
    // Verifica se um evento está ativo
    if (eventoAtual) {
        let tempoDecorridoEvento = millis() - tempoInicioEvento;
        if (tempoDecorridoEvento >= duracaoEvento) {
            // Fim do evento
            eventoAtual = null;
            proximoEventoTempo = millis() + random(intervaloEventoMin, intervaloEventoMax);
            // Reverter efeitos, se necessário (aqui, a temperatura já volta a subir e árvores ao normal)
        } else {
            // Efeitos do evento ativo
            if (eventoAtual === 'chuva') {
                temperatura = max(0, temperatura - 0.05); // Reduz a temperatura mais rápido
                // Acelerar crescimento das árvores: podemos fazer isso aqui ou na classe Arvore
                // Por enquanto, só a temperatura, para não complicar muito.
            } else if (eventoAtual === 'praga') {
                temperatura = min(40, temperatura + 0.08); // Aumenta a temperatura mais rápido (com limite)
                // Pequena perda de pontos durante a praga
                pontuacao = max(0, pontuacao - 0.05); // Perda contínua menor
            }
        }
    } else {
        // Tenta iniciar um novo evento se o tempo passou
        if (millis() >= proximoEventoTempo) {
            let tipoEvento = random(['chuva', 'praga']); // Pode adicionar mais tipos depois
            eventoAtual = tipoEvento;
            tempoInicioEvento = millis();
            duracaoEvento = random(5000, 10000); // Duração do evento entre 5 e 10 segundos

            // Efeitos iniciais do evento
            if (eventoAtual === 'chuva') {
                temperatura = max(0, temperatura - 5); // Grande queda inicial na temperatura
                pontuacao += 25; // Bônus inicial maior por chuva
                // if (somPonto) somPonto.play(); // Adicione som se tiver
            } else if (eventoAtual === 'praga') {
                temperatura = min(40, temperatura + 5); // Grande aumento inicial na temperatura (com limite)
                pontuacao = max(0, pontuacao - 20); // Perda de pontos inicial maior
                // if (somPerdaPonto) somPerdaPonto.play(); // Adicione som se tiver
            }
        }
    }
}

// Classe que cria o jardineiro
class Jardineiro {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.emoji = '👨🏻‍🌾';
        this.velocidade = 3;
        this.largura = 32;
        this.altura = 32;
    }
    atualizar() {
        if (keyIsDown(LEFT_ARROW)) {
            this.x -= this.velocidade;
        }
        if (keyIsDown(RIGHT_ARROW)) {
            this.x += this.velocidade;
        }
        if (keyIsDown(UP_ARROW)) {
            this.y -= this.velocidade;
        }
        if (keyIsDown(DOWN_ARROW)) {
            this.y += this.velocidade;
        }

        this.x = constrain(this.x, 0, width - this.largura);
        this.y = constrain(this.y, 0, height - this.altura);
    }
    mostrar() {
        textSize(32);
        text(this.emoji, this.x, this.y);
    }
}

function keyPressed() {
    // Primeiro, verifica se a tecla de reinício foi pressionada.
    // Use uma tecla diferente ou verifique por uma tecla maiúscula para reiniciar.
    if (key === 'P' || keyCode === ENTER) { // 'P' ou ENTER para reiniciar o jogo
        resetarJogo();
        return; // Sai da função para não executar outras ações
    }

    // Plantar nova árvore (muda)
    if (key === ' ' || key === 'p') { // 'p' minúsculo para plantar
        let podePlantar = true;
        for (let planta of plantas) {
            // Verifica se está muito perto de uma planta existente
            if (dist(jardineiro.x, jardineiro.y, planta.x, planta.y) < 32) {
                podePlantar = false;
                break;
            }
        }

        if (podePlantar) {
            let arvore = new Arvore(jardineiro.x, jardineiro.y);
            plantas.push(arvore);
            temperatura -= 1;
            if (temperatura < 0) temperatura = 0;
            pontuacao += 10; // Bônus por plantar muda (aumentado)
            // if (somPlantio) somPlantio.play(); // Adicione som se tiver
        }
    }

    // Replantar toco
    if (key === 'r') { // 'r' minúsculo para replantar toco
        for (let i = plantas.length - 1; i >= 0; i--) {
            let planta = plantas[i];
            if (planta.cortada && dist(jardineiro.x, jardineiro.y, planta.x, planta.y) < 32) {
                planta.cortada = false;
                planta.estagio = 0;
                temperatura -= 2;
                if (temperatura < 0) temperatura = 0;
                pontuacao += 25; // Bônus por replantar toco (aumentado)
                // if (somReplantio) somReplantio.play(); // Adicione som se tiver
                break; // Replantou um toco, pode sair do loop
            }
        }
    }
}

// --- Classe Arvore com Estágios de Crescimento ---
class Arvore {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.emoji = '🌱';
        this.cortada = false;
        this.largura = 32;
        this.altura = 32;
        this.estagio = 0;
        this.tempoCrescimento = 0;
        this.tempoParaProximoEstagio = 180;
    }

    mostrar() {
        textSize(32);
        if (this.cortada) {
            this.emoji = '🪵';
        } else if (this.estagio === 0) {
            this.emoji = '🌱';
        } else if (this.estagio === 1) {
            this.emoji = '🌿';
        } else {
            this.emoji = '🌳';
        }
        text(this.emoji, this.x, this.y);

        if (this.cortada) {
            fill(255, 255, 0, sin(frameCount * 0.1) * 50 + 100);
            noStroke();
            ellipse(this.x + this.largura / 2, this.y + this.altura / 2, 20, 20);
        }
    }

    atualizar() {
        if (!this.cortada && this.estagio < 2) {
            this.tempoCrescimento++;
            // Velocidade de crescimento afetada pela chuva (exemplo, você pode ajustar)
            let fatorCrescimento = 1;
            if (eventoAtual === 'chuva') {
                fatorCrescimento = 0.5; // Cresce 2x mais rápido durante a chuva
            }
            if (this.tempoCrescimento * fatorCrescimento >= this.tempoParaProximoEstagio) {
                this.estagio++;
                this.tempoCrescimento = 0;
                if (this.estagio === 2) {
                    totalArvores++;
                    temperatura -= 2;
                    if (temperatura < 0) temperatura = 0;
                    pontuacao += 50; // Bônus maior por árvore adulta (aumentado)
                    // if (somPonto) somPonto.play(); // Adicione som se tiver
                }
            }
        }
    }
}

// --- Classe Machado ---
class Machado {
    constructor() {
        this.x = -100;
        this.y = -100;
        this.ativo = false;
        this.largura = 80;
        this.altura = 80;
        this.velocidade = 2;
        this.alvoX = 0;
        this.alvoY = 0;
        this.modoAleatorio = false;
    }

    aparecerAleatoriamente() {
        let arvoresAdultas = plantas.filter(a => !a.cortada && a.estagio === 2);

        if (arvoresAdultas.length > 0) {
            let arvoreAlvo = random(arvoresAdultas);
            this.alvoX = arvoreAlvo.x + arvoreAlvo.largura / 2;
            this.alvoY = arvoreAlvo.y + arvoreAlvo.altura / 2;
            this.modoAleatorio = false;
        } else {
            this.modoAleatorio = true;

            let entrada = random(['cima', 'baixo', 'esquerda', 'direita']);
            let saida = random(['cima', 'baixo', 'esquerda', 'direita']);

            if (entrada === 'cima') {
                this.x = random(width);
                this.y = -this.altura;
            } else if (entrada === 'baixo') {
                this.x = random(width);
                this.y = height + this.altura;
            } else if (entrada === 'esquerda') {
                this.x = -this.largura;
                this.y = random(height);
            } else { // direita
                this.x = width + this.largura;
                this.y = random(height);
            }

            if (saida === 'cima') {
                this.alvoX = random(width);
                this.alvoY = -this.altura;
            } else if (saida === 'baixo') {
                this.alvoX = random(width);
                this.alvoY = height + this.altura;
            } else if (saida === 'esquerda') {
                this.alvoX = -this.largura;
                this.alvoY = random(height);
            } else { // direita
                this.alvoX = width + this.largura;
                this.alvoY = random(height);
            }
            if (entrada === saida) {
                this.alvoX = random(width);
                this.alvoY = random(height);
            }
        }
        this.ativo = true;
    }

    atualizar() {
        if (this.ativo) {
            let angulo = atan2(this.alvoY - this.y, this.alvoX - this.x);
            this.x += cos(angulo) * this.velocidade;
            this.y += sin(angulo) * this.velocidade;

            if (this.modoAleatorio) {
                if (this.x < -this.largura || this.x > width + this.largura || this.y < -this.altura || this.y > height + this.altura) {
                    this.desaparecer();
                    reiniciarTempoMachado();
                }
            }
        }
    }

    exibir() {
        if (this.ativo) {
            image(machadoImg, this.x, this.y, this.largura, this.altura);
        }
    }

    atingiu(arvore) {
        if (this.modoAleatorio || !this.ativo || arvore.cortada || arvore.estagio < 2) return false;

        let distancia = dist(this.x + this.largura / 2, this.y + this.altura / 2, arvore.x + arvore.largura / 2, arvore.y + arvore.altura / 2);
        return distancia < (this.largura / 2 + arvore.largura / 2) * 0.6;
    }

    desaparecer() {
        this.x = -100;
        this.y = -100;
        this.ativo = false;
        this.modoAleatorio = false;
    }
}

// --- Classe Particula ---
class Particula {
    constructor(x, y, cor = null, vx_mult = 1, vy_mult = -1) {
        this.x = x + random(-10, 10);
        this.y = y + random(-10, 10);
        this.vx = random(-1, 1) * vx_mult;
        this.vy = random(-3, -1) * vy_mult;
        this.alpha = 255;
        this.tamanho = random(3, 7);
        this.cor = cor || color(139, 69, 19);
    }

    atualizar() {
        this.x += this.vx;
        this.y += this.vy;
        this.vy += 0.05;
        this.alpha -= 5;
    }

    mostrar() {
        noStroke();
        fill(this.cor.levels[0], this.cor.levels[1], this.cor.levels[2], this.alpha);
        ellipse(this.x, this.y, this.tamanho, this.tamanho);
    }
}

function reiniciarTempoMachado() {
    tempoParaProximoMachado = random(intervaloMachadoMin, intervaloMachadoMax);
}

// --- Função: Resetar Jogo ---
function resetarJogo() {
    jardineiro = new Jardineiro(width / 2, height - 50);
    machado = new Machado();
    plantas = [];
    temperatura = 10;
    totalArvores = 0;
    pontuacao = 0;
    tempoParaProximoMachado = 0;
    particulas = [];
    reiniciarTempoMachado();

    // Resetar variáveis de evento
    proximoEventoTempo = millis() + random(intervaloEventoMin, intervaloEventoMax);
    eventoAtual = null;
    duracaoEvento = 0;
    tempoInicioEvento = 0;
}

